import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Button } from "../components/ui/button";
import { Textarea } from "../components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Separator } from "../components/ui/separator";
import { toast } from "sonner";
import { useGym } from "../context/GymContext";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import { Search, Edit, Trash2, Building2, Plus } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "../components/ui/dialog";

export function Settings() {
  const { gymSettings, updateGymSettings, plans, addPlan, updatePlan, deletePlan, gyms, addGym, switchGym, currentGym } = useGym();
  const [gymDetails, setGymDetails] = useState(gymSettings);

  useEffect(() => {
    setGymDetails(gymSettings);
  }, [gymSettings]);

  // Plan form state
  const [planForm, setPlanForm] = useState({
    name: "",
    type: "",
    duration: "",
    price: "",
    description: "",
  });

  const [editingPlan, setEditingPlan] = useState<string | null>(null);
  const [planSearchQuery, setPlanSearchQuery] = useState("");

  // Gym form state
  const [gymForm, setGymForm] = useState({
    name: "",
    location: "",
    currency: "USD",
  });
  const [isAddGymOpen, setIsAddGymOpen] = useState(false);

  const [profile, setProfile] = useState({
    name: "Admin User",
    email: "admin@fithub.com",
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const handleSaveGymDetails = (e: React.FormEvent) => {
    e.preventDefault();
    updateGymSettings(gymDetails);
    toast.success("Gym details updated successfully!");
  };

  const handleSavePlan = (e: React.FormEvent) => {
    e.preventDefault();

    if (!planForm.name || !planForm.type || !planForm.duration || !planForm.price) {
      toast.error("Please fill in all required fields");
      return;
    }

    const planData = {
      name: planForm.name,
      type: planForm.type,
      duration: parseInt(planForm.duration),
      price: parseFloat(planForm.price),
      description: planForm.description,
    };

    if (editingPlan) {
      updatePlan(editingPlan, planData);
      toast.success("Plan updated successfully!");
      setEditingPlan(null);
    } else {
      addPlan(planData);
      toast.success("Plan created successfully!");
    }

    setPlanForm({ name: "", type: "", duration: "", price: "", description: "" });
  };

  const handleEditPlan = (plan: typeof plans[0]) => {
    setPlanForm({
      name: plan.name,
      type: plan.type,
      duration: plan.duration.toString(),
      price: plan.price.toString(),
      description: plan.description,
    });
    setEditingPlan(plan.id);
  };

  const handleCancelEdit = () => {
    setEditingPlan(null);
    setPlanForm({ name: "", type: "", duration: "", price: "", description: "" });
  };

  const handleAddGym = (e: React.FormEvent) => {
    e.preventDefault();

    if (!gymForm.name || !gymForm.location) {
      toast.error("Please fill in all required fields");
      return;
    }

    addGym({
      name: gymForm.name,
      location: gymForm.location,
      currency: gymForm.currency,
      settings: {
        ...gymSettings,
        name: gymForm.name,
      },
    });

    toast.success("Gym added successfully!");
    setGymForm({ name: "", location: "", currency: "USD" });
    setIsAddGymOpen(false);
  };

  const filteredPlans = plans.filter(plan =>
    plan.name.toLowerCase().includes(planSearchQuery.toLowerCase()) ||
    plan.type.toLowerCase().includes(planSearchQuery.toLowerCase())
  );

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (profile.newPassword && profile.newPassword !== profile.confirmPassword) {
      toast.error("Passwords do not match!");
      return;
    }
    toast.success("Profile updated successfully!");
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold text-gray-900">Settings</h1>
        <p className="text-gray-500 mt-1">
          Manage settings for {currentGym?.name || "your gym"}
        </p>
      </div>

      <Tabs defaultValue="gym" className="space-y-6">
        <TabsList className="bg-white border border-gray-200">
          <TabsTrigger value="gyms">Gyms</TabsTrigger>
          <TabsTrigger value="gym">Gym Details</TabsTrigger>
          <TabsTrigger value="pricing">Plan Pricing</TabsTrigger>
          <TabsTrigger value="profile">User Profile</TabsTrigger>
        </TabsList>

        {/* Gyms Tab */}
        <TabsContent value="gyms">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Gyms</CardTitle>
                  <CardDescription>Workspaces connected to your owner account</CardDescription>
                </div>
                <Dialog open={isAddGymOpen} onOpenChange={setIsAddGymOpen}>
                  <DialogTrigger asChild>
                    <button className="inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 bg-indigo-600 text-white shadow hover:bg-indigo-700 h-9 px-4 py-2">
                      <Plus className="w-4 h-4" />
                      Add gym
                    </button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add New Gym</DialogTitle>
                      <DialogDescription>Create a new gym workspace</DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleAddGym} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="gymName">Gym Name *</Label>
                        <Input
                          id="gymName"
                          placeholder="e.g., PowerHouse Gym"
                          value={gymForm.name}
                          onChange={(e) => setGymForm({ ...gymForm, name: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="location">Location *</Label>
                        <Input
                          id="location"
                          placeholder="e.g., New York, USA"
                          value={gymForm.location}
                          onChange={(e) => setGymForm({ ...gymForm, location: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="currency">Currency</Label>
                        <Select value={gymForm.currency} onValueChange={(value) => setGymForm({ ...gymForm, currency: value })}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="USD">USD</SelectItem>
                            <SelectItem value="EUR">EUR</SelectItem>
                            <SelectItem value="GBP">GBP</SelectItem>
                            <SelectItem value="INR">INR</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="flex gap-2">
                        <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">
                          Create Gym
                        </Button>
                        <Button type="button" variant="outline" onClick={() => setIsAddGymOpen(false)}>
                          Cancel
                        </Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {gyms.map((gym) => (
                  <button
                    key={gym.id}
                    onClick={() => {
                      switchGym(gym.id);
                      toast.success(`Switched to ${gym.name}`);
                    }}
                    className={`w-full text-left p-4 rounded-lg border transition-all ${
                      currentGym?.id === gym.id
                        ? "border-indigo-600 bg-indigo-50"
                        : "border-gray-200 hover:border-indigo-300 hover:bg-gray-50"
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                        <Building2 className="w-5 h-5 text-indigo-600" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-900">{gym.name}</h3>
                        <p className="text-sm text-gray-500">{gym.location} · {gym.currency}</p>
                      </div>
                      {currentGym?.id === gym.id && (
                        <span className="text-xs bg-indigo-600 text-white px-2 py-1 rounded">Active</span>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Gym Details Tab */}
        <TabsContent value="gym">
          <Card>
            <CardHeader>
              <CardTitle>Gym Information</CardTitle>
              <CardDescription>Update your gym's basic information</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSaveGymDetails} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="gymName">Gym Name</Label>
                    <Input
                      id="gymName"
                      value={gymDetails.name}
                      onChange={(e) =>
                        setGymDetails((prev) => ({ ...prev, name: e.target.value }))
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="gymEmail">Email</Label>
                    <Input
                      id="gymEmail"
                      type="email"
                      value={gymDetails.email}
                      onChange={(e) =>
                        setGymDetails((prev) => ({ ...prev, email: e.target.value }))
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="gymPhone">Phone</Label>
                    <Input
                      id="gymPhone"
                      value={gymDetails.phone}
                      onChange={(e) =>
                        setGymDetails((prev) => ({ ...prev, phone: e.target.value }))
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="gymAddress">Address</Label>
                    <Input
                      id="gymAddress"
                      value={gymDetails.address}
                      onChange={(e) =>
                        setGymDetails((prev) => ({ ...prev, address: e.target.value }))
                      }
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="gymDescription">Description</Label>
                  <Textarea
                    id="gymDescription"
                    value={gymDetails.description}
                    onChange={(e) =>
                      setGymDetails((prev) => ({ ...prev, description: e.target.value }))
                    }
                    rows={4}
                  />
                </div>

                <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">
                  Save Changes
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Plan Pricing Tab */}
        <TabsContent value="pricing">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Create/Edit Plan Form */}
            <Card>
              <CardHeader>
                <CardTitle>{editingPlan ? "Edit membership plan" : "Create membership plan"}</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSavePlan} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="planName">Plan name</Label>
                    <Input
                      id="planName"
                      placeholder="Monthly"
                      value={planForm.name}
                      onChange={(e) => setPlanForm({ ...planForm, name: e.target.value })}
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="planType">Plan type</Label>
                      <Select
                        value={planForm.type}
                        onValueChange={(value) => setPlanForm({ ...planForm, type: value })}
                        required
                      >
                        <SelectTrigger id="planType">
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Monthly">Monthly</SelectItem>
                          <SelectItem value="Quarterly">Quarterly</SelectItem>
                          <SelectItem value="Half yearly">Half yearly</SelectItem>
                          <SelectItem value="Yearly">Yearly</SelectItem>
                          <SelectItem value="Custom">Custom</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="duration">Duration months</Label>
                      <Input
                        id="duration"
                        type="number"
                        placeholder="1"
                        value={planForm.duration}
                        onChange={(e) => setPlanForm({ ...planForm, duration: e.target.value })}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="planPrice">Price</Label>
                    <Input
                      id="planPrice"
                      type="number"
                      step="0.01"
                      placeholder="50.00"
                      value={planForm.price}
                      onChange={(e) => setPlanForm({ ...planForm, price: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="planDescription">Description</Label>
                    <Textarea
                      id="planDescription"
                      placeholder="Optional"
                      value={planForm.description}
                      onChange={(e) => setPlanForm({ ...planForm, description: e.target.value })}
                      rows={3}
                    />
                  </div>

                  <div className="flex gap-2">
                    <Button type="submit" className="bg-green-600 hover:bg-green-700">
                      {editingPlan ? "Update plan" : "Save plan"}
                    </Button>
                    {editingPlan && (
                      <Button type="button" variant="outline" onClick={handleCancelEdit}>
                        Cancel
                      </Button>
                    )}
                  </div>
                </form>
              </CardContent>
            </Card>

            {/* Plans List */}
            <Card>
              <CardHeader>
                <CardTitle>Plans</CardTitle>
                <div className="mt-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      placeholder="Search plans..."
                      value={planSearchQuery}
                      onChange={(e) => setPlanSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {filteredPlans.length === 0 ? (
                    <p className="text-center text-gray-500 py-8">No plans found</p>
                  ) : (
                    filteredPlans.map((plan) => (
                      <div
                        key={plan.id}
                        className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50"
                      >
                        <div>
                          <h3 className="font-semibold text-gray-900">{plan.name}</h3>
                          <p className="text-sm text-gray-500">
                            {plan.duration} month(s) · ${plan.price.toFixed(2)}
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditPlan(plan)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-red-600 hover:text-red-700"
                            onClick={() => {
                              if (confirm("Are you sure you want to delete this plan?")) {
                                deletePlan(plan.id);
                                toast.success("Plan deleted successfully!");
                              }
                            }}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* User Profile Tab */}
        <TabsContent value="profile">
          <Card>
            <CardHeader>
              <CardTitle>User Profile</CardTitle>
              <CardDescription>Manage your account settings</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSaveProfile} className="space-y-6">
                <div className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="profileName">Full Name</Label>
                    <Input
                      id="profileName"
                      value={profile.name}
                      onChange={(e) =>
                        setProfile((prev) => ({ ...prev, name: e.target.value }))
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="profileEmail">Email</Label>
                    <Input
                      id="profileEmail"
                      type="email"
                      value={profile.email}
                      onChange={(e) =>
                        setProfile((prev) => ({ ...prev, email: e.target.value }))
                      }
                    />
                  </div>

                  <Separator />

                  <div className="space-y-4">
                    <h3 className="font-medium">Change Password</h3>

                    <div className="space-y-2">
                      <Label htmlFor="currentPassword">Current Password</Label>
                      <Input
                        id="currentPassword"
                        type="password"
                        value={profile.currentPassword}
                        onChange={(e) =>
                          setProfile((prev) => ({ ...prev, currentPassword: e.target.value }))
                        }
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="newPassword">New Password</Label>
                      <Input
                        id="newPassword"
                        type="password"
                        value={profile.newPassword}
                        onChange={(e) =>
                          setProfile((prev) => ({ ...prev, newPassword: e.target.value }))
                        }
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword">Confirm New Password</Label>
                      <Input
                        id="confirmPassword"
                        type="password"
                        value={profile.confirmPassword}
                        onChange={(e) =>
                          setProfile((prev) => ({ ...prev, confirmPassword: e.target.value }))
                        }
                      />
                    </div>
                  </div>
                </div>

                <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">
                  Save Profile
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
