import { useState, useEffect } from "react";
import { Link, useSearchParams } from "react-router";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import { Search, Edit, UserPlus, Archive } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../components/ui/table";

const membersData = [
  { id: 1, name: "John Smith", phone: "+1 234-567-8901", plan: "Monthly", expiryDate: "2026-06-05", status: "Active", archived: false },
  { id: 2, name: "Sarah Johnson", phone: "+1 234-567-8902", plan: "Quarterly", expiryDate: "2026-06-20", status: "Active", archived: false },
  { id: 3, name: "Mike Davis", phone: "+1 234-567-8903", plan: "Yearly", expiryDate: "2027-03-10", status: "Active", archived: false },
  { id: 4, name: "Emily Brown", phone: "+1 234-567-8904", plan: "Monthly", expiryDate: "2026-04-20", status: "Expired", archived: false },
  { id: 5, name: "David Wilson", phone: "+1 234-567-8905", plan: "Quarterly", expiryDate: "2026-07-05", status: "Active", archived: false },
  { id: 6, name: "Lisa Anderson", phone: "+1 234-567-8906", plan: "Monthly", expiryDate: "2026-05-25", status: "Active", archived: false },
  { id: 7, name: "Tom Martinez", phone: "+1 234-567-8907", plan: "Yearly", expiryDate: "2026-12-30", status: "Active", archived: false },
  { id: 8, name: "Jennifer Taylor", phone: "+1 234-567-8908", plan: "Monthly", expiryDate: "2026-04-18", status: "Expired", archived: false },
  { id: 9, name: "Robert Lee", phone: "+1 234-567-8909", plan: "Quarterly", expiryDate: "2026-08-15", status: "Active", archived: false },
  { id: 10, name: "Amanda White", phone: "+1 234-567-8910", plan: "Monthly", expiryDate: "2026-06-10", status: "Active", archived: false },
  { id: 11, name: "James Wilson", phone: "+1 234-567-8911", plan: "Monthly", expiryDate: "2025-12-15", status: "Active", archived: true },
  { id: 12, name: "Patricia Moore", phone: "+1 234-567-8912", plan: "Quarterly", expiryDate: "2025-11-20", status: "Expired", archived: true },
  { id: 13, name: "Michael Brown", phone: "+1 234-567-8913", plan: "Yearly", expiryDate: "2025-10-10", status: "Active", archived: true },
];

export function Members() {
  const [searchParams] = useSearchParams();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [planFilter, setPlanFilter] = useState("all");
  const [activeTab, setActiveTab] = useState("all");

  // Handle URL search params for filtering
  useEffect(() => {
    const status = searchParams.get("status");
    if (status) {
      setStatusFilter(status);
    }
  }, [searchParams]);

  // Helper function to calculate actual status based on expiry date
  const getActualStatus = (member: typeof membersData[0]) => {
    const today = new Date();
    const expiryDate = new Date(member.expiryDate);
    const daysUntilExpiry = Math.ceil((expiryDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

    // If already expired
    if (member.status === "Expired" || daysUntilExpiry < 0) {
      return "Expired";
    }

    // If expiring within 30 days
    if (daysUntilExpiry <= 30) {
      return "Expiring Soon";
    }

    // Otherwise active
    return "Active";
  };

  const getFilteredMembers = (showArchived: boolean) => {
    return membersData.filter((member) => {
      const matchesSearch =
        member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        member.phone.includes(searchQuery);

      const actualStatus = getActualStatus(member);
      const matchesStatus = statusFilter === "all" || actualStatus === statusFilter;
      const matchesPlan = planFilter === "all" || member.plan === planFilter;
      const matchesArchived = member.archived === showArchived;

      return matchesSearch && matchesStatus && matchesPlan && matchesArchived;
    });
  };

  const activeMembers = getFilteredMembers(false);
  const archivedMembers = getFilteredMembers(true);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold text-gray-900">Members</h1>
          <p className="text-gray-500 mt-1">Manage all gym members</p>
        </div>
        <Link to="/members/add">
          <Button className="bg-indigo-600 hover:bg-indigo-700">
            <UserPlus className="w-4 h-4 mr-2" />
            Add Member
          </Button>
        </Link>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Members Management</CardTitle>
              <CardDescription>
                Search, filter, and manage your gym members
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Search and Filters */}
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search by name or phone..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-[180px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="Active">Active</SelectItem>
                <SelectItem value="Expiring Soon">Expiring Soon</SelectItem>
                <SelectItem value="Expired">Expired</SelectItem>
              </SelectContent>
            </Select>
            <Select value={planFilter} onValueChange={setPlanFilter}>
              <SelectTrigger className="w-full md:w-[180px]">
                <SelectValue placeholder="Plan" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Plans</SelectItem>
                <SelectItem value="Monthly">Monthly</SelectItem>
                <SelectItem value="Quarterly">Quarterly</SelectItem>
                <SelectItem value="Yearly">Yearly</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="bg-gray-100 p-1">
              <TabsTrigger
                value="all"
                className="data-[state=active]:bg-indigo-600 data-[state=active]:text-white"
              >
                All Members
              </TabsTrigger>
              <TabsTrigger
                value="archived"
                className="data-[state=active]:bg-orange-600 data-[state=active]:text-white"
              >
                Archived
              </TabsTrigger>
            </TabsList>

            {/* All Members Tab */}
            <TabsContent value="all">
              <div className="rounded-lg border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Phone</TableHead>
                      <TableHead>Plan</TableHead>
                      <TableHead>Expiry Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {activeMembers.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                          No members found
                        </TableCell>
                      </TableRow>
                    ) : (
                      activeMembers.map((member) => {
                        const actualStatus = getActualStatus(member);
                        return (
                          <TableRow key={member.id}>
                            <TableCell className="font-medium">{member.name}</TableCell>
                            <TableCell>{member.phone}</TableCell>
                            <TableCell>
                              <Badge variant="outline">{member.plan}</Badge>
                            </TableCell>
                            <TableCell>{member.expiryDate}</TableCell>
                            <TableCell>
                              <Badge
                                variant={
                                  actualStatus === "Expired"
                                    ? "destructive"
                                    : actualStatus === "Expiring Soon"
                                    ? "secondary"
                                    : "default"
                                }
                                className={
                                  actualStatus === "Active"
                                    ? "bg-green-100 text-green-700 hover:bg-green-200"
                                    : actualStatus === "Expiring Soon"
                                    ? "bg-yellow-100 text-yellow-700 hover:bg-yellow-200"
                                    : ""
                                }
                              >
                                {actualStatus}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2">
                                <Button variant="ghost" size="sm">
                                  <Edit className="w-4 h-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="text-orange-600 hover:text-orange-700"
                                >
                                  <Archive className="w-4 h-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })
                    )}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            {/* Archived Tab */}
            <TabsContent value="archived">
              <div className="rounded-lg border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Phone</TableHead>
                      <TableHead>Plan</TableHead>
                      <TableHead>Expiry Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {archivedMembers.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                          No archived members found
                        </TableCell>
                      </TableRow>
                    ) : (
                      archivedMembers.map((member) => {
                        const actualStatus = getActualStatus(member);
                        return (
                          <TableRow key={member.id}>
                            <TableCell className="font-medium">{member.name}</TableCell>
                            <TableCell>{member.phone}</TableCell>
                            <TableCell>
                              <Badge variant="outline">{member.plan}</Badge>
                            </TableCell>
                            <TableCell>{member.expiryDate}</TableCell>
                            <TableCell>
                              <Badge
                                variant={
                                  actualStatus === "Expired"
                                    ? "destructive"
                                    : actualStatus === "Expiring Soon"
                                    ? "secondary"
                                    : "default"
                                }
                                className={
                                  actualStatus === "Active"
                                    ? "bg-green-100 text-green-700 hover:bg-green-200"
                                    : actualStatus === "Expiring Soon"
                                    ? "bg-yellow-100 text-yellow-700 hover:bg-yellow-200"
                                    : ""
                                }
                              >
                                {actualStatus}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2">
                                <Button variant="ghost" size="sm">
                                  <Edit className="w-4 h-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })
                    )}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
