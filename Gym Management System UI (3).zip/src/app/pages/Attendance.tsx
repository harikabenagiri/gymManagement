import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Search, CheckCircle } from "lucide-react";
import { toast } from "sonner";

const todayAttendance = [
  { id: 1, name: "John Smith", checkInTime: "06:15 AM", plan: "Monthly" },
  { id: 2, name: "Sarah Johnson", checkInTime: "07:30 AM", plan: "Quarterly" },
  { id: 3, name: "Mike Davis", checkInTime: "08:00 AM", plan: "Yearly" },
  { id: 4, name: "David Wilson", checkInTime: "09:15 AM", plan: "Quarterly" },
  { id: 5, name: "Lisa Anderson", checkInTime: "10:45 AM", plan: "Monthly" },
  { id: 6, name: "Tom Martinez", checkInTime: "11:30 AM", plan: "Yearly" },
  { id: 7, name: "Robert Lee", checkInTime: "02:15 PM", plan: "Quarterly" },
  { id: 8, name: "Amanda White", checkInTime: "03:45 PM", plan: "Monthly" },
];

const activeMembers = [
  { id: 9, name: "Emily Brown", phone: "+1 234-567-8904", plan: "Monthly" },
  { id: 10, name: "Jennifer Taylor", phone: "+1 234-567-8908", plan: "Quarterly" },
  { id: 11, name: "James Anderson", phone: "+1 234-567-8911", plan: "Yearly" },
];

export function Attendance() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedMember, setSelectedMember] = useState<typeof activeMembers[0] | null>(null);

  const filteredMembers = activeMembers.filter((member) =>
    member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    member.phone.includes(searchQuery)
  );

  const handleMarkPresent = () => {
    if (selectedMember) {
      toast.success(`${selectedMember.name} marked present!`);
      setSelectedMember(null);
      setSearchQuery("");
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold text-gray-900">Attendance</h1>
        <p className="text-gray-500 mt-1">Track daily member check-ins</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Mark Attendance */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Mark Attendance</CardTitle>
            <CardDescription>Search and mark a member present</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search member..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Search Results */}
            {searchQuery && (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {filteredMembers.length === 0 ? (
                  <p className="text-sm text-gray-500 text-center py-4">No members found</p>
                ) : (
                  filteredMembers.map((member) => (
                    <button
                      key={member.id}
                      onClick={() => setSelectedMember(member)}
                      className={`w-full p-3 rounded-lg border text-left transition-colors ${
                        selectedMember?.id === member.id
                          ? "border-indigo-600 bg-indigo-50"
                          : "border-gray-200 hover:bg-gray-50"
                      }`}
                    >
                      <p className="font-medium text-gray-900">{member.name}</p>
                      <p className="text-sm text-gray-500">{member.phone}</p>
                      <Badge variant="outline" className="mt-1">
                        {member.plan}
                      </Badge>
                    </button>
                  ))
                )}
              </div>
            )}

            {/* Selected Member */}
            {selectedMember && (
              <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-lg">
                <p className="text-sm text-indigo-600 mb-1">Selected Member</p>
                <p className="font-medium text-gray-900">{selectedMember.name}</p>
                <p className="text-sm text-gray-500">{selectedMember.phone}</p>
              </div>
            )}

            {/* Mark Present Button */}
            <Button
              onClick={handleMarkPresent}
              disabled={!selectedMember}
              className="w-full bg-indigo-600 hover:bg-indigo-700"
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              Mark Present
            </Button>
          </CardContent>
        </Card>

        {/* Today's Attendance List */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Today's Attendance</CardTitle>
            <CardDescription>
              {todayAttendance.length} members checked in today
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {todayAttendance.map((record) => (
                <div
                  key={record.id}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{record.name}</p>
                      <p className="text-sm text-gray-500">{record.checkInTime}</p>
                    </div>
                  </div>
                  <Badge variant="outline">{record.plan}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
