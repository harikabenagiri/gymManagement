import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Users, UserCheck, AlertCircle, ClipboardCheck, DollarSign } from "lucide-react";
import { Badge } from "../components/ui/badge";
import { useGym } from "../context/GymContext";
import { Link } from "react-router";

const statsData = [
  {
    title: "Total Members",
    value: "248",
    icon: Users,
    color: "text-blue-600",
    bgColor: "bg-blue-50",
    link: "/members",
  },
  {
    title: "Active Members",
    value: "215",
    icon: UserCheck,
    color: "text-green-600",
    bgColor: "bg-green-50",
    link: "/members?status=Active",
  },
  {
    title: "Expiring Soon",
    value: "18",
    icon: AlertCircle,
    color: "text-orange-600",
    bgColor: "bg-orange-50",
    link: "/members?status=Expiring Soon",
  },
  {
    title: "Today's Check-ins",
    value: "42",
    icon: ClipboardCheck,
    color: "text-purple-600",
    bgColor: "bg-purple-50",
    link: "/attendance",
  },
  {
    title: "Monthly Revenue",
    value: "$12,450",
    icon: DollarSign,
    color: "text-indigo-600",
    bgColor: "bg-indigo-50",
    link: "/payments",
  },
];

const attendanceData = [
  { id: "att-mon", day: "Mon", checkIns: 45 },
  { id: "att-tue", day: "Tue", checkIns: 52 },
  { id: "att-wed", day: "Wed", checkIns: 48 },
  { id: "att-thu", day: "Thu", checkIns: 61 },
  { id: "att-fri", day: "Fri", checkIns: 55 },
  { id: "att-sat", day: "Sat", checkIns: 67 },
  { id: "att-sun", day: "Sun", checkIns: 43 },
];

const revenueData = [
  { id: "rev-jan", month: "Jan", revenue: 11200 },
  { id: "rev-feb", month: "Feb", revenue: 11800 },
  { id: "rev-mar", month: "Mar", revenue: 12100 },
  { id: "rev-apr", month: "Apr", revenue: 12450 },
];

const expiringMembers = [
  { id: 1, name: "John Smith", phone: "+1 234-567-8901", plan: "Monthly", expiryDate: "2026-04-28", daysLeft: 2 },
  { id: 2, name: "Sarah Johnson", phone: "+1 234-567-8902", plan: "Quarterly", expiryDate: "2026-04-30", daysLeft: 4 },
  { id: 3, name: "Mike Davis", phone: "+1 234-567-8903", plan: "Monthly", expiryDate: "2026-05-02", daysLeft: 6 },
  { id: 4, name: "Emily Brown", phone: "+1 234-567-8904", plan: "Yearly", expiryDate: "2026-05-05", daysLeft: 9 },
  { id: 5, name: "David Wilson", phone: "+1 234-567-8905", plan: "Monthly", expiryDate: "2026-05-08", daysLeft: 12 },
];

export function Dashboard() {
  const { gymSettings } = useGym();

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
          {gymSettings.name}
        </h1>
        <p className="text-gray-500 mt-2">Welcome back! Here's your gym overview.</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        {statsData.map((stat) => {
          const Icon = stat.icon;
          return (
            <Link key={stat.title} to={stat.link}>
              <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm text-gray-600">{stat.title}</p>
                      <p className="text-2xl font-semibold mt-2">{stat.value}</p>
                    </div>
                    <div className={`${stat.bgColor} p-3 rounded-lg`}>
                      <Icon className={`w-5 h-5 ${stat.color}`} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          );
        })}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Attendance Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Attendance Trend</CardTitle>
            <CardDescription>Daily check-ins for the last 7 days</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {attendanceData.map((item) => {
                const maxCheckIns = 70;
                const percentage = (item.checkIns / maxCheckIns) * 100;

                return (
                  <div key={item.id} className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-medium text-gray-700">{item.day}</span>
                      <span className="font-semibold text-indigo-600">{item.checkIns}</span>
                    </div>
                    <div className="w-full bg-gray-100 rounded-full h-3">
                      <div
                        className="bg-indigo-600 h-3 rounded-full transition-all duration-300"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Revenue Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Revenue Trend</CardTitle>
            <CardDescription>Monthly revenue over the last 4 months</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {revenueData.map((item) => {
                const maxRevenue = 13000;
                const percentage = (item.revenue / maxRevenue) * 100;

                return (
                  <div key={item.id} className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-medium text-gray-700">{item.month}</span>
                      <span className="font-semibold text-indigo-600">
                        ${item.revenue.toLocaleString()}
                      </span>
                    </div>
                    <div className="w-full bg-gray-100 rounded-full h-3">
                      <div
                        className="bg-indigo-600 h-3 rounded-full transition-all duration-300"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Expiring Memberships */}
      <Card>
        <CardHeader>
          <CardTitle>Expiring Memberships</CardTitle>
          <CardDescription>Members whose memberships are expiring soon</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {expiringMembers.map((member) => (
              <div
                key={member.id}
                className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{member.name}</p>
                  <p className="text-sm text-gray-500">{member.phone}</p>
                </div>
                <div className="flex items-center gap-4">
                  <Badge variant="outline" className="bg-white">
                    {member.plan}
                  </Badge>
                  <div className="text-right">
                    <p className="text-sm text-gray-900">{member.expiryDate}</p>
                    <p className="text-xs text-orange-600">{member.daysLeft} days left</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
