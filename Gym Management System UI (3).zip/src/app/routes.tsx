import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { Login } from "./pages/Login";
import { Dashboard } from "./pages/Dashboard";
import { Members } from "./pages/Members";
import { AddMember } from "./pages/AddMember";
import { Attendance } from "./pages/Attendance";
import { Payments } from "./pages/Payments";
import { AddPayment } from "./pages/AddPayment";
import { Settings } from "./pages/Settings";

export const router = createBrowserRouter([
  {
    path: "/login",
    Component: Login,
  },
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Dashboard },
      { path: "members", Component: Members },
      { path: "members/add", Component: AddMember },
      { path: "attendance", Component: Attendance },
      { path: "payments", Component: Payments },
      { path: "payments/add", Component: AddPayment },
      { path: "settings", Component: Settings },
    ],
  },
]);
