import { createContext, useContext, useState, ReactNode } from "react";

interface GymSettings {
  name: string;
  email: string;
  phone: string;
  address: string;
  description: string;
}

interface Gym {
  id: string;
  name: string;
  location: string;
  currency: string;
  settings: GymSettings;
}

interface MembershipPlan {
  id: string;
  name: string;
  type: string;
  duration: number;
  price: number;
  description: string;
}

interface GymContextType {
  gymSettings: GymSettings;
  updateGymSettings: (settings: GymSettings) => void;
  gyms: Gym[];
  currentGym: Gym | null;
  addGym: (gym: Omit<Gym, "id">) => void;
  switchGym: (gymId: string) => void;
  plans: MembershipPlan[];
  addPlan: (plan: Omit<MembershipPlan, "id">) => void;
  updatePlan: (id: string, plan: Omit<MembershipPlan, "id">) => void;
  deletePlan: (id: string) => void;
}

const defaultGymSettings: GymSettings = {
  name: "FitHub Gym",
  email: "contact@fithub.com",
  phone: "+1 234-567-8900",
  address: "123 Fitness Street, Gym City, GC 12345",
  description: "Your premier fitness destination",
};

const defaultGym: Gym = {
  id: "gym-1",
  name: "FitHub Gym",
  location: "New York, USA",
  currency: "USD",
  settings: defaultGymSettings,
};

const defaultPlans: MembershipPlan[] = [
  { id: "plan-1", name: "Monthly", type: "Monthly", duration: 1, price: 50, description: "Monthly membership" },
  { id: "plan-2", name: "Quarterly", type: "Quarterly", duration: 3, price: 135, description: "Quarterly membership" },
  { id: "plan-3", name: "Half-Yearly", type: "Half yearly", duration: 6, price: 240, description: "Half yearly membership" },
  { id: "plan-4", name: "Yearly", type: "Yearly", duration: 12, price: 480, description: "Yearly membership" },
];

const GymContext = createContext<GymContextType | undefined>(undefined);

export function GymProvider({ children }: { children: ReactNode }) {
  const [gyms, setGyms] = useState<Gym[]>(() => {
    const saved = localStorage.getItem("gyms");
    return saved ? JSON.parse(saved) : [defaultGym];
  });

  const [currentGym, setCurrentGym] = useState<Gym>(() => {
    const savedCurrentGymId = localStorage.getItem("currentGymId");
    if (savedCurrentGymId) {
      const saved = localStorage.getItem("gyms");
      const allGyms = saved ? JSON.parse(saved) : [defaultGym];
      return allGyms.find((g: Gym) => g.id === savedCurrentGymId) || allGyms[0];
    }
    return gyms[0] || defaultGym;
  });

  const [plans, setPlans] = useState<MembershipPlan[]>(() => {
    const saved = localStorage.getItem(`plans-${currentGym.id}`);
    return saved ? JSON.parse(saved) : defaultPlans;
  });

  const gymSettings = currentGym.settings;

  const updateGymSettings = (settings: GymSettings) => {
    const updatedGym = { ...currentGym, settings };
    setCurrentGym(updatedGym);

    const updatedGyms = gyms.map(g => g.id === currentGym.id ? updatedGym : g);
    setGyms(updatedGyms);
    localStorage.setItem("gyms", JSON.stringify(updatedGyms));
  };

  const addGym = (gym: Omit<Gym, "id">) => {
    const newGym: Gym = {
      ...gym,
      id: `gym-${Date.now()}`,
    };
    const updatedGyms = [...gyms, newGym];
    setGyms(updatedGyms);
    localStorage.setItem("gyms", JSON.stringify(updatedGyms));
  };

  const switchGym = (gymId: string) => {
    const gym = gyms.find(g => g.id === gymId);
    if (gym) {
      setCurrentGym(gym);
      localStorage.setItem("currentGymId", gymId);

      // Load plans for this gym
      const saved = localStorage.getItem(`plans-${gymId}`);
      setPlans(saved ? JSON.parse(saved) : defaultPlans);
    }
  };

  const addPlan = (plan: Omit<MembershipPlan, "id">) => {
    const newPlan: MembershipPlan = {
      ...plan,
      id: `plan-${Date.now()}`,
    };
    const updatedPlans = [...plans, newPlan];
    setPlans(updatedPlans);
    localStorage.setItem(`plans-${currentGym.id}`, JSON.stringify(updatedPlans));
  };

  const updatePlan = (id: string, plan: Omit<MembershipPlan, "id">) => {
    const updatedPlans = plans.map(p => p.id === id ? { ...plan, id } : p);
    setPlans(updatedPlans);
    localStorage.setItem(`plans-${currentGym.id}`, JSON.stringify(updatedPlans));
  };

  const deletePlan = (id: string) => {
    const updatedPlans = plans.filter(p => p.id !== id);
    setPlans(updatedPlans);
    localStorage.setItem(`plans-${currentGym.id}`, JSON.stringify(updatedPlans));
  };

  return (
    <GymContext.Provider value={{
      gymSettings,
      updateGymSettings,
      gyms,
      currentGym,
      addGym,
      switchGym,
      plans,
      addPlan,
      updatePlan,
      deletePlan,
    }}>
      {children}
    </GymContext.Provider>
  );
}

export function useGym() {
  const context = useContext(GymContext);
  if (context === undefined) {
    throw new Error("useGym must be used within a GymProvider");
  }
  return context;
}
